﻿
namespace CoffeeManagement.Utilities
{
    public static class AppConstants
    {
		//public const string AppName = "CFM - QUẢN LÝ QUÁN CÀ PHÊ";
    }
}
