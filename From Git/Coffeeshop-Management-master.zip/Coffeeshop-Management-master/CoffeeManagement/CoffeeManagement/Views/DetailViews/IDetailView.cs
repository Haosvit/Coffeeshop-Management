﻿namespace CoffeeManagement.Views.DetailViews
{
    public interface IDetailView
    {
        string ScreenName { get; }
    }
}
