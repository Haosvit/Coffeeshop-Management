﻿
using System.Windows.Forms;

namespace CoffeeManagement.Views.Popups
{
    public partial class Indicator : Form
    {
        public Indicator()
        {
            InitializeComponent();
        }

    }
}
